#!/bin/bash
./MVGE
